package de.csg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public class Main {
    public static void main(String[] args) throws IOException {
        HttpClient httpclient = HttpClientBuilder.create().build();
        FaceAPI gesichtserkennung = new FaceAPI("37919a58658a4df1b17f2e76af5cd074", "https://francecentral.api.cognitive.microsoft.com/face/v1.0/detect");

        System.out.println("Willkommen beim Emotions-Checker \"Happy-o-Meter\"\nBitte gebe einen Link ein:");

        BufferedReader EingabeReader = new BufferedReader(new InputStreamReader(System.in));
        String Zeileneingabe = EingabeReader.readLine().replaceAll("\\s+","");

        if (istEingabeEineUrl(Zeileneingabe)) {
            String rueckgabeWert = gesichtserkennung.SendRequest(Zeileneingabe, httpclient);

            if (!rueckgabeWert.isEmpty()) {
                JSONArray apiAntwort = new JSONArray(rueckgabeWert);
                JSONObject emotionen = apiAntwort.getJSONObject(0).getJSONObject("faceAttributes").getJSONObject("emotion");
                ArrayList<Integer> emotionArray = new ArrayList<Integer>();

                emotionArray.add(emotionen.getInt("contempt"));
                emotionArray.add(emotionen.getInt("surprise"));
                emotionArray.add(emotionen.getInt("happiness"));
                emotionArray.add(emotionen.getInt("neutral"));
                emotionArray.add(emotionen.getInt("sadness"));
                emotionArray.add(emotionen.getInt("disgust"));
                emotionArray.add(emotionen.getInt("anger"));
                emotionArray.add(emotionen.getInt("fear"));

                for (int i = 0; i < emotionen.length(); i++) {
                    System.out.println(emotionArray.get(2).toString());
                }

            } else {
                System.out.println("Es gab keine Antwort von der API! Bitte versuche es erneut.");
            }
        } else {
            System.out.println("Bei der Eingabe handelt es sich nicht um eine URL!\nBitte versuche es erneut!");
        }
    }

    private static Boolean istEingabeEineUrl(String url){
        Boolean rtn = true;

        try {
            URL testUrl = new URL(url);
            URLConnection conn = testUrl.openConnection();
            conn.connect();
        } catch (MalformedURLException e) {
            rtn = false;
        } catch (IOException e) {
            rtn = false;
        }

        return rtn;
    }
}
