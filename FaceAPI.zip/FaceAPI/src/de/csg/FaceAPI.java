package de.csg;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;

public class FaceAPI {
    private String subscriptionKey;
    private String uriBase;
    private String faceAttributes;

    public String getSubscriptionKey() {
        return subscriptionKey;
    }

    public void setSubscriptionKey(String subscriptionKey) {
        this.subscriptionKey = subscriptionKey;
    }

    public String getUriBase() {
        return uriBase;
    }

    public void setUriBase(String uriBase) {
        this.uriBase = uriBase;
    }

    public String getFaceAttributes() {
        return faceAttributes;
    }

    public void setFaceAttributes(String faceAttributes) {
        this.faceAttributes = faceAttributes;
    }

    public FaceAPI(String subscriptionKey, String uriBase) {
        this.subscriptionKey = subscriptionKey;
        this.uriBase = uriBase;

        this.faceAttributes = "age,gender,emotion";
    }

    public String SendRequest(String imageURL, HttpClient httpclient) {
        String returnString = "";

        try
        {
            URIBuilder builder = new URIBuilder(this.uriBase);

            // Request parameters. All of them are optional.
            builder.setParameter("returnFaceId", "true");
            builder.setParameter("returnFaceLandmarks", "false");
            builder.setParameter("returnFaceAttributes", this.faceAttributes);

            // Prepare the URI for the REST API call.
            URI uri = builder.build();
            HttpPost request = new HttpPost(uri);

            // Request headers.
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Ocp-Apim-Subscription-Key", this.subscriptionKey);

            // Request body.
            StringEntity reqEntity = new StringEntity("{\"url\":\""+imageURL+"\"}");
            request.setEntity(reqEntity);

            // Execute the REST API call and get the response entity.
            HttpResponse response = httpclient.execute(request);
            HttpEntity entity = response.getEntity();

            if (entity != null)
            {
                // Format and display the JSON response.
                String jsonString = EntityUtils.toString(entity).trim();
                if (jsonString.charAt(0) == '[') {
                    JSONArray jsonArray = new JSONArray(jsonString);
                    returnString = jsonArray.toString(2);
                }
                else if (jsonString.charAt(0) == '{') {
                    JSONObject jsonObject = new JSONObject(jsonString);
                    returnString = jsonObject.toString(2);
                } else {
                    returnString = jsonString;
                }
            }
        }
        catch (Exception e)
        {
            returnString = e.getMessage();
        }

        return returnString;
    }
}